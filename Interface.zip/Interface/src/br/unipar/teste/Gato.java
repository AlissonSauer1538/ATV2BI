package br.unipar.teste;

import br.unipar.interfaceAnimais.Animais;

public class Gato implements Animais {
    @Override
    public String emitirSom() {
        return "miaumiau";
    }

    @Override
    public void correr() {

    }

    @Override
    public void Alimentacao() {

    }
}

package br.unipar.teste;

import br.unipar.interfaceAnimais.Animais;

public class Cachorro implements Animais {

    @Override
    public String emitirSom() {
        return "AUAUAUAUAAU";
    }

    @Override
    public void correr() {
        Integer velocidade = 10;

    }
}

package br.unipar.interfaceAnimais;

public interface Animais {
    public String emitirSom();
    public void correr();
    public void Alimentacao();
}

package br.unipar.entity;

public class DepartamentoGerente extends Funcionario {

    private Double bonificacao;

    public Double getBonificacao() {
        return bonificacao;
    }

    public void setBonificacao(Double bonificacao) {
        this.bonificacao = bonificacao;
    }
}

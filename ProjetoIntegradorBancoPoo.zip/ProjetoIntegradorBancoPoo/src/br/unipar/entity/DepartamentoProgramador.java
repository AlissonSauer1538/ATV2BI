package br.unipar.entity;

public class DepartamentoProgramador extends Funcionario {
    private String classificacao;

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }
}

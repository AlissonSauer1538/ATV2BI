package br.unipar.entity;

public class DepartamentoProjeto extends Funcionario {
    private String projeto;

    public String getProjeto() {
        return projeto;
    }

    public void setProjeto(String projeto) {
        this.projeto = projeto;
    }
}

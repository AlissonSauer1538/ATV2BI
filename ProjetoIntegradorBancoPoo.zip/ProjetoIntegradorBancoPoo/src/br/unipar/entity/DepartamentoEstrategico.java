package br.unipar.entity;

public class DepartamentoEstrategico extends Funcionario{
    private String estrategia;

    public String getEstrategia() {
        return estrategia;
    }

    public void setEstrategia(String estrategia) {
        this.estrategia = estrategia;
    }
}

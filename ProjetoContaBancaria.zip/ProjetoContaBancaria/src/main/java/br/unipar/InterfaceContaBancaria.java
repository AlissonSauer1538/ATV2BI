package br.unipar;

public interface InterfaceContaBancaria {
    Double obterSaldo();
    void depositar(Double valor);
    String retornarNumeroConata();
    boolean saque(Double valor);
}
